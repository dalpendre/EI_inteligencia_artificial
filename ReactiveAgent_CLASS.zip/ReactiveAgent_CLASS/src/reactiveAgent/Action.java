package reactiveAgent;

public enum Action {
    NORTH, SOUTH, EAST, WEST
}