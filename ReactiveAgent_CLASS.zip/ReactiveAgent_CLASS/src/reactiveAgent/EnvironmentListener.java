package reactiveAgent;


public interface EnvironmentListener {
	
    void environmentUpdated();
}
