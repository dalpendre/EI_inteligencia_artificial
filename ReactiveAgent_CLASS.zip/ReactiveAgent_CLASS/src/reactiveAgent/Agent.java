package reactiveAgent;


public interface Agent {

    void act(Environment environment);

}