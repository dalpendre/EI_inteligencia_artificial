package experiments;

public interface ExperimentListener{
    
    void experimentEnded(ExperimentEvent event);
}
